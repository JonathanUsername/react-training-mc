import React from 'react';
import * as components from './HelloWorld';
import source from '!!raw-loader!./HelloWorld';
import Prism from 'prismjs';

const Section = props => {
  const first = source.indexOf(`PART${props.idx}`) + 6;
  const last = source.indexOf(`PART${props.idx + 1}`) - 4;
  const code = source.substring(first, last);
  return (
    <pre className='language-js'>
      {Prism.highlight(code, Prism.languages.javascript)}
    </pre>
  );
};

// Here's where we put them all together:
class Layout extends React.Component {
  constructor() {
    super();
    this.state = {
      counter: 0
    };
    this.up = () => {
      const {counter} = this.state;
      this.setState({
        counter: counter < 10 ? counter + 1 : counter
      });
    }
    this.down = () => {
      const {counter} = this.state;
      this.setState({
        counter: counter > 0 ? counter - 1 : counter
      });
    }
  }
  


  render() {
    const arr = Object.keys(components).map(i => components[i]);
    
    return (
      <div>
        <div style={{position: 'fixed', top: '0', right: '0'}}>
          <button onClick={this.down}>Wait, back it up</button>
          <button onClick={this.up}>Onwards!</button>
        </div>
        Part {this.state.counter}
        {arr.map((Component, idx) => idx > this.state.counter ? null : (
          <div>
            {JSON.stringify(Component)}
            <div>
              <div style={{border: 'solid #ddd', padding: '5px 20px'}}>
                <Component key={idx} {...this.props} />
              </div>
            </div>
            <div>
              <h2>Code:</h2>
              <Section source={source} idx={idx} />
            </div>
          </div>
        ))}
      </div>
    );
  }
}

export default Layout;